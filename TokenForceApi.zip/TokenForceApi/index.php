 
        <?php            
             require_once 'bll/TokenForceApi.php';             
             $tokenforceAPI = new TokenForceApi();
             $tokenforceAPI->apiRest();           
        ?>
 