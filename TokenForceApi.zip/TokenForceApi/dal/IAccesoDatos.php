<?php // Interface que expone todo lo que el DAL (Capa Acceso Datos) implementa

interface IAccesoDatos {
    public function obtenerListadoUsuarios();       // Obtiene el listado de todos los usuarios
    public function obtenerUsuario($DatoBuscar);    // Obtiene un usuario
    public function guardarUsuario($usuario);       // Ingresa y/o actualiza un usuario
    public function eliminarUsuario($DatoEliminar); // Elimina un usuario
}
