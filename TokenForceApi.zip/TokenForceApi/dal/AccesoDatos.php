<?php // DAL: Data Access Layer - Capa Acceso Datos

require_once 'bo/Usuario.php';
require_once 'Conexion.php';
require_once 'IAccesoDatos.php';

class AccesoDatos implements IAccesoDatos{
    
   private $cn = null;      // Alias para la Conexion 
      
    public function obtenerListadoUsuarios() 
    { 
        $cn = Conexion::obtenerConexion();
        $listado = array();         
        try
        {
            $rs= $cn->query("CALL spr_Listados(0)"); 
            $rows = $rs->fetch_all(MYSQLI_ASSOC);
            foreach ($rows as $row) 
            {     
                $usuario = new Usuario();
                $usuario->setUsuario_id($row["Usuario_Id"]);
                $usuario->setNombres($row["Nombres"]);
                $usuario->setApellidos($row["Apellidos"]); 
                array_push($listado, $usuario);                
            }
            mysqli_free_result($rs);
            mysqli_close($cn);           
            return $listado;
        }
        catch (Exception $ex)
        {
           echo $ex;
        }   
    }

    public function obtenerUsuario($usuario_id) 
    {
        $usuario = new Usuario(); 
        $cn = Conexion::obtenerConexion();
        try
        { 
             if (is_numeric($usuario_id)) 
             { 
                $rs = $cn->query("CALL spr_Listados('" . $usuario_id . "')");
                $row =  $rs->fetch_row();  
                if ($row != null)
                {
                   $usuario = $row;                  
                }              
                mysqli_free_result($rs);
                mysqli_close($cn);                
             }                    
        }
        catch (Exception $ex)
        {
          echo $ex;
        }
         return $usuario;
    }
    
    public function guardarUsuario($usuario)
    {
        $cn = Conexion::obtenerConexion();    
        try
        {        
           $cn->query("SET @result = 1");
           $cn->query("CALL spr_IUUsuarios('" . $usuario->getUsuario_id() . "', 
                                           '" . $usuario->getNombres() . "', 
                                           '" . $usuario->getApellidos() . "',                                               
                                           @result)");

           $res = $cn->query("SELECT @result AS result");
           $row = $res->fetch_assoc();
           mysqli_close($cn);
           return $row['result'];
        }
        catch (Exception $ex)
        {
          mysqli_close($cn);
          echo $ex;
        }     
    } 
  
    

    public function eliminarUsuario($usuario_id)
    {
      $resultado = '-1'; 
      try
      {   
        if (is_numeric($usuario_id)) 
        {  
            $cn = Conexion::obtenerConexion();    
            $cn->query("SET @result = 1");
            $cn->query("CALL spr_DUsuario('" . $usuario_id . "',  @result)");
            $res = $cn->query("SELECT @result AS result");
            $row = $res->fetch_assoc();
            mysqli_close($cn);
            $resultado = $row['result'];
        }
        return $resultado;
      }
      catch (Exception $ex)
      {
        mysqli_close($cn);
        echo $ex;
      }  
    }
}

?>


