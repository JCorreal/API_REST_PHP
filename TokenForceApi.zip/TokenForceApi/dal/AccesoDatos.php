<?php // DAL: Data Access Layer - Capa Acceso Datos

require_once 'bo/Usuario.php';
require_once 'Conexion.php';
require_once 'IAccesoDatos.php';

class AccesoDatos implements IAccesoDatos{
    
    private $cn = NULL;      // Alias para la Conexion
    private $vecr = array(); // Vector con Resultados
  
   private static function buscarRegistro($DatoBuscar)
   { // Funcion para buscar un registro especifico             
     try 
     {           
        $cn = Conexion::obtenerConexion();
        $rs= $cn->query("CALL spr_Listados('" . $DatoBuscar . "')");
        $vecresultado = array(); // Recorremos el resultado de la consulta y lo almacenamos en el array
        while ($fila = $rs->fetch_row()) 
        {
            array_push($vecresultado, $fila);                
        }
        mysqli_free_result($rs);
        mysqli_close($cn);
        return $vecresultado;
     }
     catch (Exception $ex)
     { 
       mysqli_close($cn);
       echo $ex;     
     }
   }
  
    public function obtenerListadoUsuarios() {
     $cn = Conexion::obtenerConexion();
     $DatoBuscar = 0;
     $ListaUsuarios = array();
     $vecr = array(); 
     try
     {
             $rs= $cn->query("CALL spr_Listados('" . $DatoBuscar . "')");  
             $i=0;
             while ($fila = $rs->fetch_row()) 
             {
                    array_push($vecr, $fila);   
                    $usuario = new Usuario();
                    $usuario->setUsuario_id($vecr[$i][0]);
                    $usuario->setNombres($vecr[$i][1]);
                    $usuario->setApellidos($vecr[$i][2]); 
                    array_push($ListaUsuarios, $usuario);
                    $i++;
             }
             mysqli_free_result($rs);
             mysqli_close($cn);
             return $ListaUsuarios;
       }
       catch (Exception $ex)
       {
           echo $ex;
       }   
  }

    public function guardarUsuario($usuario) {
     $cn = Conexion::obtenerConexion();    
     try
     {        
        $cn->query("SET @result = 1");
        $cn->query("CALL spr_IUUsuarios('" . $usuario->getUsuario_id() . "', 
                                        '" . $usuario->getNombres() . "', 
                                        '" . $usuario->getApellidos() . "',                                               
                                        @result)");

          $res = $cn->query("SELECT @result AS result");
          $row = $res->fetch_assoc();
          mysqli_close($cn);
          if($row['result'] == 0) 
          {
            return 0;
          }
          else 
          {
              return -1;
          }
   }
   catch (Exception $ex)
   {
       mysqli_close($cn);
       echo $ex;
   }     
 } 
  
    public function obtenerUsuario($DatoBuscar) {  
     try
     {         
          $vecr = AccesoDatos::buscarRegistro($DatoBuscar);
          if ($vecr!= NULL)
          {
            $usuario = new Usuario();
            $usuario->setUsuario_id($vecr[0][0]);
            $usuario->setNombres($vecr[0][1]);
            $usuario->setApellidos($vecr[0][2]); 
            $vecr = NULL;
            return $usuario;
          }
          else
          {
              return NULL;
          }
       }
       catch (Exception $ex)
       {
           echo $ex;
       }   
    }

    public function eliminarUsuario($DatoEliminar)
    {
     try
     {   
        $cn = Conexion::obtenerConexion();    
        $cn->query("SET @result = 1");
        $cn->query("CALL spr_DUsuario('" . $DatoEliminar . "',  @result)");

        $res = $cn->query("SELECT @result AS result");
        $row = $res->fetch_assoc();
        mysqli_close($cn);
        return $row['result'];
     }
     catch (Exception $ex)
     {
        mysqli_close($cn);
        echo $ex;
     }  
    }
}

?>


