<?php // Clase que nos devuelve la conexion con el proveedor que se desee

class Conexion {
 
 public static function obtenerConexion()
 {
    try
    {       
        $conexion = new mysqli("127.0.0.1", "root", "root", "ApiRest_DB");
        if (mysqli_connect_errno())
        {       
            die("No se puede conectar a la base de datos:");
        }
        else 
        {
           return($conexion);
        }         
    }
    catch (Exception $ex)
    { 
       echo $ex;     
    }
 }

}

 
