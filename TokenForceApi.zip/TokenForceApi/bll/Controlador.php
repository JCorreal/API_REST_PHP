<?php // Este es el Controlador Manager general de todo el sistema. Todo tiene que pasar por esta clase
     require_once 'dal/AccesoDatos.php';       
     
 class Controlador  {
    
    protected $iaccesoDatos;
    
    public function __construct(IAccesodatos $iaccesoDatos)
    {
        $this->iaccesoDatos=new AccesoDatos();
    }             
  
    public function obtenerListadoUsuarios() 
    {
       return $this->iaccesoDatos->obtenerListadoUsuarios();
    }
    
    public function obtenerUsuario($DatoBuscar)
    {
        return $this->iaccesoDatos->obtenerUsuario($DatoBuscar);
    }
    
    public function guardarUsuario ($Object)
    {
       return $this->iaccesoDatos->guardarUsuario($Object); 
    }
    
    public function eliminarUsuario ($DatoEliminar)
    {
       return $this->iaccesoDatos->eliminarUsuario($DatoEliminar); 
    }
 }
