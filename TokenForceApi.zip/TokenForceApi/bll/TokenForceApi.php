<?php // Este es el servicio Rest como tal, quien recibe las peticiones desde el exterior
     ini_set('display_errors', 1);
     ini_set('display_startup_errors', 1);
     error_reporting(E_ALL);
     require_once 'Funciones.php';       
     
     
class TokenForceAPI {
    
    public function __construct(){}
             
    public function apiRest()
    {
        header('Content-Type: application/JSON');    
        $method = $_SERVER['REQUEST_METHOD'];
            
            switch ($method)
            {
            case 'GET':
                 $this->obtenerInformacion();
                 break;     
            case 'POST':
                 $this->agregarUsuario();
                 break;                
            case 'PUT':
                 $this->agregarUsuario();
                 break;                         
            case 'DELETE':
                 $this->eliminarUsuario();
                 break;
            default: 
                 echo 'Metodo No Valido';
                 break;
            }            
            
    }
    
    
 function obtenerInformacion(){     
     $DatoBuscar = (isset($_GET['id']) && $_GET['id']) ? $_GET['id'] : NULL;
     $controlador = Funciones::crearControlador(); 
     if ($DatoBuscar!= NULL) 
     {
         $response = $controlador->obtenerUsuario($DatoBuscar);             
     }    
     else
     {
         $response = $controlador->obtenerListadoUsuarios();              
     }   
     echo json_encode($response, JSON_PRETTY_PRINT);  
     
 }
 
 function agregarUsuario(){
     $obj = json_decode( file_get_contents('php://input') );   
     $objArr = (array)$obj;        
     if (empty($objArr))
     {
        $this->response(422,"Error","No hay datos json");                           
     }
     else
     {
                $usuario = new Usuario();    
                $usuario->setUsuario_id($obj->usuario_id);
                $usuario->setNombres($obj->nombres);
                $usuario->setApellidos($obj->apellidos);
                $controlador = Funciones::crearControlador();
                $Resultado = $controlador->guardarUsuario($usuario); 
                if ($Resultado == 0)
                {
                   if ($usuario->getUsuario_id() == 0)
                   {
                     $this->response(200,"Exito", "El nuevo registro ha sido grabado");
                   }
                   else 
                   {
                     if ($Resultado == 0)
                     {  
                       $this->response(200,"Exito", "El registro ha sido actualizado");                         
                     }
                     else if ($Resultado == -2)
                     {             
                       $this->response(200,"Error","No existe este usuario");
                     }  
                     else
                     {
                       $this->response(200,"Error","Se ha producido un error accesando la base de datos");                         
                     }                  
                   }
                }                
                else 
                {
                 $this->response(200,"Error","Se ha producido un error accesando la base de datos");
                }                             
     }
 }
 
 
 function eliminarUsuario(){            
     $DatoBuscar=NULL;
     if(isset($_GET['id']))
     {
        $DatoBuscar = $_GET['id'];
     }    
     $controlador = Funciones::crearControlador();
     $Resultado = $controlador->eliminarUsuario($DatoBuscar);
     if ($Resultado == 0)
     {
        $this->response(200,"Exito", "El registro ha sido eliminado");
     }
     else if ($Resultado == -2)
     {             
        $this->response(200,"Error","No existe este usuario");
     }
     else
     {             
         $this->response(200,"Error","Se ha producido un error accesando la base de datos");
     }              
 }
 
 
    function response($code=200, $status="", $message="") {
    http_response_code($code);
    if( !empty($status) && !empty($message) ){
        $response = array("status" => $status ,"message"=>$message);  
        echo json_encode($response,JSON_PRETTY_PRINT);    
    }            
 }   
}