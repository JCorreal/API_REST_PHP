<?php // Este es el servicio Rest como tal, quien recibe las peticiones desde el exterior
     
     ini_set('display_errors', 1);
     ini_set('display_startup_errors', 1);
     error_reporting(E_ALL);
     
     require_once 'Funciones.php';       
               
class TokenForceAPI {
    
    public function __construct(){}
             
    public function apiRest()
    {
        header('Content-Type: application/JSON');    
        $opcion = $_SERVER['REQUEST_METHOD'];
            
            switch ($opcion)
            {
            case 'GET':
                 $this->obtenerInformacion();
                 break;     
            case 'POST':
                 $this->agregarUsuario();
                 break;                
            case 'PUT':
                 $this->agregarUsuario();
                 break;                         
            case 'DELETE':
                 $this->eliminarUsuario();
                 break;
            default: 
                 echo 'Metodo No Valido';
                 break;
            }            
            
    }
    
    
 function obtenerInformacion(){  
     
     // **==**==**==**==**==**==**==**==**==**==**==**==**==**==**==**   
     $longitud = strlen(DOMINIO); // Constante con la URL empleada
     $host= $_SERVER["HTTP_HOST"];
     $url= $_SERVER["REQUEST_URI"];
     $miurl = "http://" . $host . $url;     
     $usuario_id = substr($miurl, $longitud, strlen($miurl));
     // **==**==**==**==**==**==**==**==**==**==**==**==**==**==**==**    
            
     $controlador = Funciones::crearControlador(); 
     if (strlen($usuario_id) > 0 ) 
     {
         $response = $controlador->obtenerUsuario($usuario_id);             
     }    
     else
     {
         $response = $controlador->obtenerListadoUsuarios();              
     }   
     echo json_encode($response, JSON_PRETTY_PRINT);  
     
 }
 
 function agregarUsuario(){   
     $data = json_decode(file_get_contents("php://input"));          
     if(is_null($data->usuario_id) || empty($data->nombres) || empty($data->apellidos))
     {
        $this->response(UNPROCESSABLE_ENTITY, "Error", ERRORSD);                           
     }     
     else
     {
                $usuario = new Usuario();    
                $usuario->setUsuario_id($data->usuario_id);
                $usuario->setNombres($data->nombres);
                $usuario->setApellidos($data->apellidos);
                $controlador = Funciones::crearControlador();
                $resultado = $controlador->guardarUsuario($usuario); 
                                
                if ($resultado == 0)
                {
                   if ($usuario->getUsuario_id() == 0)
                   {
                     $this->response(OK,"Exito", EXITOI);
                   }    
                   else 
                   {
                       $this->response(OK,"Exito", EXITOU);                     
                   }
                }    
                else if ($resultado == -2)
                {             
                       $this->response(OK,"Error",ERRORUD);
                }  
                else
                {
                       $this->response(OK,"Error",ERRORDB);                         
                }                             
     }
 }
 
 
 function eliminarUsuario(){            
     // **==**==**==**==**==**==**==**==**==**==**==**==**==**==**==** 
     $longitud = strlen(DOMINIO); // Constante con la URL empleada
     $host= $_SERVER["HTTP_HOST"];
     $url= $_SERVER["REQUEST_URI"];
     $miurl = "http://" . $host . $url;     
     $usuario_id = substr($miurl, $longitud, strlen($miurl));
     // **==**==**==**==**==**==**==**==**==**==**==**==**==**==**==** 
     if (strlen($usuario_id) > 0 ) 
     {
        $controlador = Funciones::crearControlador();
        $resultado = $controlador->eliminarUsuario($usuario_id);
        if ($resultado == 0)
        {
           $this->response(OK,"Exito", EXITOD);
        }
        else if ($resultado == -2)
        {             
           $this->response(OK,"Error", ERRORUD);
        }
        else
        {             
            $this->response(OK,"Error", ERRORDB);
        }
     }
 }
 
 
    function response($code, $status, $message) {
    http_response_code($code);
    if( !empty($status) && !empty($message) ){
        $response = array("Codigo" => $code, "Estado" => $status ,"Mensaje"=>$message);  
        echo json_encode($response,JSON_PRETTY_PRINT);    
    }            
 }   
}