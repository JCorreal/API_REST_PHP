<?php // Este es el servicio Rest como tal, quien recibe las peticiones desde el exterior
     
     ini_set('display_errors', 1);
     ini_set('display_startup_errors', 1);
     error_reporting(E_ALL);
     
     require_once 'Funciones.php';       
               
class TokenForceAPI {
    
    public function __construct(){}
             
    public function apiRest()
    {
        header('Content-Type: application/JSON');    
        $opcion = $_SERVER['REQUEST_METHOD'];
            
            switch ($opcion)
            {
            case 'GET':
                 $this->obtenerInformacion();
                 break;     
            case 'POST':
                 $this->agregarUsuario();
                 break;                
            case 'PUT':
                 $this->agregarUsuario();
                 break;                         
            case 'DELETE':
                 $this->eliminarUsuario();
                 break;
            default: 
                 echo 'Metodo No Valido';
                 break;
            }            
            
    }
    
    
 function obtenerInformacion(){  
     
     // **==**==**==**==**==**==**==**==**==**==**==**==**==**==**==**   
     $longitud = strlen(DOMINIO); // Constante con la URL empleada
     $host= $_SERVER["HTTP_HOST"];
     $url= $_SERVER["REQUEST_URI"];
     $miurl = "http://" . $host . $url;     
     $usuario_id = substr($miurl, $longitud, strlen($miurl));
     // **==**==**==**==**==**==**==**==**==**==**==**==**==**==**==**    
            
     $controlador = Funciones::crearControlador(); 
     if (strlen($usuario_id) > 0 ) 
     {
         $response = $controlador->obtenerUsuario($usuario_id);             
     }    
     else
     {
         $response = $controlador->obtenerListadoUsuarios();              
     }   
     echo json_encode($response, JSON_PRETTY_PRINT);  
     
 }
 
 function agregarUsuario(){
     $obj = json_decode( file_get_contents('php://input') );   
     $objArr = (array)$obj;        
     if (empty($objArr))
     {
        $this->response(422,"Error","No hay datos json");                           
     }
     else
     {
                $usuario = new Usuario();    
                $usuario->setUsuario_id($obj->usuario_id);
                $usuario->setNombres($obj->nombres);
                $usuario->setApellidos($obj->apellidos);
                $controlador = Funciones::crearControlador();
                $resultado = $controlador->guardarUsuario($usuario); 
                if ($resultado == 0)
                {
                   if ($usuario->getUsuario_id() == 0)
                   {
                     $this->response(200,"Exito", "El nuevo registro ha sido grabado");
                   }
                   else 
                   {
                     if ($resultado == 0)
                     {  
                       $this->response(200,"Exito", "El registro ha sido actualizado");                         
                     }
                     else if ($resultado == -2)
                     {             
                       $this->response(200,"Error","No existe este usuario");
                     }  
                     else
                     {
                       $this->response(200,"Error","Se ha producido un error accesando la base de datos");                         
                     }                  
                   }
                }                
                else 
                {
                 $this->response(200,"Error","Se ha producido un error accesando la base de datos");
                }                             
     }
 }
 
 
 function eliminarUsuario(){            
     // **==**==**==**==**==**==**==**==**==**==**==**==**==**==**==** 
     $longitud = strlen(DOMINIO); // Constante con la URL empleada
     $host= $_SERVER["HTTP_HOST"];
     $url= $_SERVER["REQUEST_URI"];
     $miurl = "http://" . $host . $url;     
     $usuario_id = substr($miurl, $longitud, strlen($miurl));
     // **==**==**==**==**==**==**==**==**==**==**==**==**==**==**==** 
     if (strlen($usuario_id) > 0 ) 
     {
        $controlador = Funciones::crearControlador();
        $resultado = $controlador->eliminarUsuario($usuario_id);
        if ($resultado == 0)
        {
           $this->response(200,"Exito", "El registro ha sido eliminado");
        }
        else if ($resultado == -2)
        {             
           $this->response(200,"Error","No existe este usuario");
        }
        else
        {             
            $this->response(200,"Error","Se ha producido un error accesando la base de datos");
        }
     }
 }
 
 
    function response($code=200, $status="", $message="") {
    http_response_code($code);
    if( !empty($status) && !empty($message) ){
        $response = array("status" => $status ,"message"=>$message);  
        echo json_encode($response,JSON_PRETTY_PRINT);    
    }            
 }   
}