<?php // Esta es una clase transversal, desde donde se instancia el Factory Method
     require_once 'bll/Controlador.php';
     require_once 'bll/AccesoDatosFactory.php';      
     
     const DOMINIO = "http://localhost/TokenForceApi/index.php/usuarios/";
     
class Funciones
{   
   
   public static function crearControlador()
   {
        $accesodatos = new AccesoDatos();
        $accesodatos = AccesoDatosFactory::getAccesoDatos($accesodatos);       
        return new Controlador($accesodatos);
   }
}