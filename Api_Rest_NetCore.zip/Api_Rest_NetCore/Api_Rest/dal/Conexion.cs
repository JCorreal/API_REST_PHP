﻿using System;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Json;

namespace Api_Rest.dal
{
    public class Conexion 
    {             
        static IConfigurationBuilder builder = new ConfigurationBuilder().AddJsonFile("appsettings.json", false, true);
    
        public static IConfigurationRoot configuration = builder.Build();

        public static string obtenerConexion
        {             
            get
            {
              // return @"server=localhost;userid=root;password='';database=ApiRest_DB";   
              return configuration.GetConnectionString("DBConnection");           
            }
        }
    }
}