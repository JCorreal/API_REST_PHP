namespace Api_Rest.bo;

public class Usuario
{    
    private int Usuario_Id = 0;
    private string Nombres;
    private string Apellidos;

    // Default Constructor
    public Usuario() { }

    public int usuario_id { get; set; }

    public string nombres { get; set; }

    public string apellidos { get; set; }
     
}
