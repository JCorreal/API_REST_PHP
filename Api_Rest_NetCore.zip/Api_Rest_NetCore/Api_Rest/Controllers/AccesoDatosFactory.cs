﻿using Api_Rest.dal;

namespace Api_Rest.Controllers
{
    public static class AccesoDatosFactory
    {
        public static IAccesoDatos GetAccesoDatos()
        {
            return new AccesoDatos();
        }
    }
}