<?php // DAL: Data Access Layer - Capa Acceso Datos

require_once 'bo/Usuario.php';
require_once 'Conexion.php';
require_once 'IAccesoDatos.php';

class AccesoDatos implements IAccesoDatos{
    
   private $cn = null;      // Alias para la Conexion 
      
    public function obtenerListadoUsuarios() 
    { 
        $cn = Conexion::obtenerConexion();
        $listado = array();         
        try
        {
            $rs = oci_parse($cn, "CALL SPR_LISTADOS(0, :rc)");            
            $refcur = oci_new_cursor($cn);
            oci_bind_by_name($rs, ':rc', $refcur, -1, OCI_B_CURSOR);
            oci_execute($rs);
            oci_execute($refcur); 
            while($row = oci_fetch_array($refcur, OCI_NUM))
            {
               array_push($listado, $row);        
            }
            oci_free_statement($refcur); 
            oci_close($cn);           
            return $listado;
        }
        catch (Exception $ex)
        {
           oci_close($cn);
           echo $ex;
        }   
    }

    public function obtenerUsuario($usuario_id) 
    {
        $usuario = new Usuario(); 
        $cn = Conexion::obtenerConexion();
        try
        { 
            if (is_numeric($usuario_id)) 
            { 
                $rs = oci_parse($cn, "CALL SPR_LISTADOS( $usuario_id, :rc)");     
                $refcur = oci_new_cursor($cn);
                oci_bind_by_name($rs, ':rc', $refcur, -1, OCI_B_CURSOR);
                oci_execute($rs);
                oci_execute($refcur); 
                $usuario = oci_fetch_object($refcur);               
                oci_free_statement($refcur); 
                oci_close($cn);           
                return $usuario; 
            }
        }        
        catch (Exception $ex)
        {
          oci_close($cn);
          echo $ex;
        }
    }
    
    public function guardarUsuario($usuario)
    {
        $resultado = -1;
        $cn = Conexion::obtenerConexion();    
        try
        {        
            $stid = oci_parse($cn, "CALL SPR_IUUSUARIOS( '" . $usuario->getUsuario_id() . "',
                                                         '" . $usuario->getNombres() . "', 
                                                         '" . $usuario->getApellidos() . "', 
                                                         :result)");

            oci_bind_by_name($stid, ':result', $resultado, 2);
            oci_execute($stid);
            oci_free_statement($stid);       
            oci_close($cn);  
        }
        catch (Exception $ex)
        {
          oci_close($cn);
          echo $ex;
        }  
        return $resultado;
    } 
  
    

    public function eliminarUsuario($usuario_id)
    {
      $resultado = '-1'; 
      try
      {   
        if (is_numeric($usuario_id)) 
        {  
            $cn = Conexion::obtenerConexion();   
            $stid = oci_parse($cn, "CALL SPR_DUSUARIO( '" . $usuario_id . "',  :result)");
            oci_bind_by_name($stid, ':result', $resultado, 2);
            oci_execute($stid);
            oci_free_statement($stid);       
            oci_close($cn);  
        }
        return $resultado;
      }
      catch (Exception $ex)
      {
        mysqli_close($cn);
        echo $ex;
      }  
    }
}

?>


